% Z_b=[];
% S_b=[];
% Z_b=iter_Z{1};
% S_b=iter_S{1};
% for i=1:2000
%    for j=1:2000
%        if abs(Z_b(i,j))<=0.002
%             Z_b(i,j)=0;
%        else
%             Z_b(i,j)=1; 
%        end
%    end
% end
% 
% for i=1:2000
%    for j=1:2000
%        if abs(S_b(i,j))<=0.002
%             S_b(i,j)=0;
%        else
%             S_b(i,j)=1; 
%        end
%    end
% end
% Z
% imagesc(Z_b);colormap(jet);axis off;%colorbar
% set(gcf, 'position', [0 0 650 550]);
% figure 
% imagesc(S_b);colormap(jet);axis off;%colorbar
% set(gcf, 'position', [0 0 650 550])


for j=2
    figure
imagesc(X{j}*X{j}');colormap(jet);axis off;%colorbar
set(gcf, 'position', [0 0 650 550]);
colorbar%�ұ���ɫ��ʾ��
end
% for i=1:9
% figure 
% imagesc(resofeachiterS_S{i,1});colormap(jet);axis off;%colorbar
% set(gcf, 'position', [0 0 650 550])
% colorbar%�ұ���ɫ��ʾ��
% end
% resofeachiterS_Z = [resofeachiterS_Z;S0,Z];
% figure 
% imagesc(iter_Z{32});colormap(jet);axis off;%colorbar
% set(gcf, 'position', [0 0 650 550])

colorbar%�ұ���ɫ��ʾ��
% colormap(jet);
