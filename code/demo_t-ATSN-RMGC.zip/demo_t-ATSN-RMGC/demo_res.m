clear all;
addpath(genpath('./ClusteringMeasure'))
addpath(genpath('./code_coregspectral'))
addpath(genpath('./funs'))
addpath(genpath('./libs'))
addpath(genpath('./tproduct-master'))
addpath(genpath('./twist'))
addpath(genpath('./multiview-datasets'))
addpath(genpath('./LRR'))
fprintf('�����������Multi-view EnergyPreserve Clustering�����������\n');
usepca = 0;
options = [];
options.ReducedDim = 100;  %Fixed 
ds={'yale_mtv_m','UCI_3view','handwritten','Caltech101-7','Caltech101-20','scene15','Caltech101-all'};

%ѡ�����ݿ�
 for di = 1
load(ds{di});ds{di}
gt = Y;
if ~isempty(find(gt==0,1))
    gt = gt + 1; %�����ǩ��0��ʼ���
end
num_views = size(X,2);
num_Clust = size(unique(gt),1);
nmu_samples = length(gt);
for i=1:num_views
%       X{i} = NormalizeFea(X{i},1);%ע������淶��
%       [X{i}]=NormalizeData(X{i});
%      X{i} = X{i}./repmat(sqrt(sum(X{i}.^2,1)),size(X{i},1),1);
    if size(X{i},2)~=nmu_samples  %�������cell�Ƿ��ǰ��д洢��Ϊ������PCA����
        X{i} = X{i}';
    end
%     if usepca==1
%         if size(X{i},2)>options.ReducedDim
%             [P1,~] = PCA1(X{i},options); %ÿһ��һ������
%             X{i}=X{i}*P1;
%         end
%     end
    X{i} = X{i}'; %n*d��ת��
end

%��������
% alpha = 10;
% beta = 100; 
% label2 = {'10^{-3}','10^{-2}', '10^{-1}', '1', '10^{1}', '10^{2}','10^{3}'};%��ǩlamada2
% label1 = {'10^{-3}','10^{-2}', '10^{-1}', '1', '10^{1}', '10^{2}','10^{3}'};%��ǩ lamada1
% pn = 10;
% m = 100;
% lambda=1;

max_iter=30;
arr_gamma=1;
% arr_gamma = [1e-3, 1e-2,1e-1,1,10,100,1000];
% arr_alpha = [1e-3, 1e-2,1e-1,1,10,100,1000];
% arr_alpha = [20, 30,50,100,150,200];
arr_alpha = [20];
arr_beta =  [1e-3, 1e-2,1e-1,1,10,100,1000];
% arr_beta = [20, 30,50,100,150,200];
% arr_beta = [200];
% arr_alpha = [30];
arr_beta = [150];
% arr_m = [100];
% arr_m =[10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200];
% arr_m =[10,20,30,40,50,60,70,80,90,100,110];
arr_p = [0.8];
% arr_p = [0.1:0.1:1];
% arr_m = [50, 100, 150,200,250,300];
% arr_pn = [10,20,30,32,40,50];
%[Fscore, Precision, Recall, MIhat, AR, Entropy, ACC, Purity]
savedata = [];
for l = 1:length(arr_p)
        for i = 1:length(arr_alpha)
            for j = 1:length(arr_beta) 
                 for ij = 1:length(arr_gamma) 
                p = arr_p(l);
                alpha = arr_alpha(i);
                beta = arr_beta(j);
                gamma = arr_gamma(ij);
                [resofeachiterS_S,resofeachiterS_Z,Z,W,obj,S,resofeachiter,history,results] = ASTGT(X,gt,alpha,beta,gamma,p,max_iter);
              %[Fscore, Precision, Recall, MIhat, AR, Entropy, ACC, Purity]
                savedata = [savedata; p, alpha, beta,results,S,W];
                fprintf('.');
                 end
            end
            fprintf('\n');
        end
%     end
end
tm=datestr(now,'yyyy-mm-dd_HH_MM_SS');
% fs = [ds{di},'_EP_'];
% save(['./res_paras/',ds{di},'_EP_',tm],'savedata');
res_file = fullfile('./res/', [tm, ds{di}, '.mat']);%��Ҫ�Ƚ���res�ļ����ܴ洢
save(res_file, 'savedata');
% clear savedata;
 end
% load train
% sound(y,Fs)



