%% For convinience, we assume the order of the tensor is always 3;
clear;
addpath('tSVD','proxFunctions','solvers','twist');
addpath('ClusteringMeasure', 'LRR', 'Nuclear_norm_l21_Algorithm', 'unlocbox');


load('UCI_digit_mfeat.mat');
X1 = mfeat_pix'; X2 = mfeat_fou'; X3 = mfeat_mor';
X{1} = X1; X{2} = X2; X{3} = X3; gt = truth;
cls_num = length(unique(gt));

%data preparation...
K = length(X);%��ͼ������
N = size(X{1},2); %sample number
 for v=1:K
    [X{v}]=NormalizeData(X{v});
     %X{v} = zscore(X{v},1);
 end


for k=1:K
    Z{k} = zeros(N,N); 
    W{k} = zeros(N,N);
    G{k} = zeros(N,N);
    E{k} = zeros(size(X{k},1),N); 
    D{k}=L2_distance_1(X{k},X{k});
end

w = zeros(N*N*K,1);
g = zeros(N*N*K,1);
dim1 = N;dim2 = N;dim3 = K;
myNorm = 'tSVD_1';
sX = [N, N, K];
%set Default
parOP         =    false;
ABSTOL        =    1e-6;
RELTOL        =    1e-4;


Isconverg = 0;epson = 1e-7;
iter = 0;
CMV_Date = []; j = 1;
alpha=100;
beta=10000; 
rho = 0.0001; max_rho = 10e15; pho_rho = 2;
tic;
for retry=1:20
while(Isconverg == 0)
    fprintf('----processing iter %d--------\n', iter+1);
    for k=1:K
        %1 update Z^k
        
        tmp = rho*G{k} + 2*X{k}'*X{k} - D{k}' - W{k};
        B12=inv((2*alpha+rho)*eye(N,N)+ X{k}'*X{k})*tmp;
        B = (B12 + B12')/2;
        Z{k} = project_fantope(B,cls_num); 
        
    end
    
 
    %4 update G
    Z_tensor = cat(3, Z{:,:});
    W_tensor = cat(3, W{:,:});
    Ten = Z_tensor + W_tensor/rho;
    Ten=shiftdim(Ten, 1);
    [G_tensor,objV,~] = prox_tnn(Ten, beta/rho);
    G_tensor = shiftdim(G_tensor, 2);
    
    %5 update W
    W_tensor = W_tensor + rho*(Z_tensor - G_tensor);
    
    %record the iteration information
    history.objval(iter+1)   =  objV;

    %% coverge condition
    Isconverg = 1;
    for k=1:K
        
        G{k} = G_tensor(:,:,k);
        W_tensor = reshape(w, sX);
        W{k} = W_tensor(:,:,k);
        if (norm(Z{k}-G{k},inf)>epson)
%             history.norm_Z_G = norm(Z{k}-G{k},inf);
%             fprintf('norm_Z_G %7.10f    \n', history.norm_Z_G);
            Isconverg = 0;
        end
    end
   
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    rho = min(rho*pho_rho, max_rho);
end
S = 0;
for k=1:K
    S = S + abs(Z{k})+abs(Z{k}');
end
C = SpectralClustering(S,cls_num);
[A nmi avgent] = compute_nmi(gt,C);
ACC = Accuracy(C,double(gt));
[f,p,r] = compute_f(gt,C);
[AR,RI,MI,HI]=RandIndex(gt,C);
toc;
                  CMV_Date(j,1) = alpha; CMV_Date(j,2) = beta;  
                  CMV_Date(j,3) = ACC;   CMV_Date(j,4) = nmi;     CMV_Date(j,5) = AR;
                  CMV_Date(j,6) = f;       CMV_Date(j,7) = p;       CMV_Date(j,8) = r; 
                  
                  j = j + 1;
end
save Result_CMV CMV_Date
mACC = mean(CMV_Date(:,3));
mnmi = mean(CMV_Date(:,4));
mAR = mean(CMV_Date(:,5));
mf = mean(CMV_Date(:,6));
mp = mean(CMV_Date(:,7));
mr = mean(CMV_Date(:,8));
sACC = std(CMV_Date(:,3));
snmi = std(CMV_Date(:,4));
sAR = std(CMV_Date(:,5));
sf = std(CMV_Date(:,6));
sp = std(CMV_Date(:,7));
sr = std(CMV_Date(:,8));
