clear all;
addpath(genpath('./multiview-datasets'))
addpath(genpath(pwd))
fprintf('�����������Multi-view Clustering�����������\n');
usepca = 0;
options = [];
options.ReducedDim = 100;  %Fixed 
ds={'Reuters_100_C5','Reuters','MSRCv1','scene15','UCI_3view','yale_mtv_m','handwritten','Caltech101-7','Caltech101-20','COIL20','Caltech101-all'};


 di =5;
load(ds{di});
ds{di}
gt = Y;
if ~isempty(find(gt==0,1))
    gt = gt + 1;
end
num_views = size(X,2);
num_Clust = size(unique(Y),1);
nmu_samples = length(gt);
for i=1:num_views

    if size(X{i},2)~=nmu_samples  
        X{i} = X{i}';
    end
    X{i} = X{i}'; %
end
%% init parameters
alpha = 30;
beta = 150;
gamma = 5;
 p = 0.8;
max_iter = 20;
%%
res = [];
for retry=1:1
    tic
    [S,resofeachiter,history,results] = t_ATSN(X,gt,alpha,beta,gamma,p,max_iter);
    t=toc;
    res = [res;t,results];
end

load train
sound(y,Fs)
% end


