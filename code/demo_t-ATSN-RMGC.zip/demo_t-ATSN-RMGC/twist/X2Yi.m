function Y = X2Yi(X, i)

Y = Trans_Faces(shiftdim(X, i-1));