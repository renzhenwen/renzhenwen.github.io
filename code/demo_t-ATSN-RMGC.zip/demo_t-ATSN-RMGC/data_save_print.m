function data_save_print(retry,dataset, res,paras)


tm=datestr(now,'yyyy-mm-dd_HH_MM_SS');

TM = mean(res(:,1));
Fscore = mean(res(:,2))*100;
Precision = mean(res(:,3))*100;
Recall = mean(res(:,4))*100;
MIhat = mean(res(:,5))*100;
AR = mean(res(:,6))*100;
Entropy = mean(res(:,7))*100;
ACC = mean(res(:,8))*100;
purity = mean(res(:,9))*100;
sTM = std(res(:,1));
sFscore = std(res(:,2))*100;
sPrecision = std(res(:,3))*100;
sRecall = std(res(:,4))*100;
sMIhat = std(res(:,5))*100;
sAR = std(res(:,6))*100;
sEntropy = std(res(:,7))*100;
sACC = std(res(:,8))*100;
spurity = std(res(:,9))*100;
fprintf('@ %s \n', dataset);
fprintf('@ alpha:%5.4f / beta:%5.4f/ k:%d/ m:%d \n', paras.alpha, paras.beta,paras.k,paras.m);%3.1һλ�����㡮.���������С����λ����ǰ���Ǿ���
fprintf('@ ACC:%5.2f / NMI:%5.2f / Purity:%5.2f / \n', ACC,MIhat,purity);

fileID = fopen(['log/',dataset,'5R.txt'],'a');
fprintf(fileID,'%s\n',tm);
fprintf(fileID,'@ alpha:%5.4f / beta:%5.4f/ k:%d/ m:%d \n', paras.alpha, paras.beta,paras.k,paras.m);
fprintf(fileID,'TM:%5.2f ACC:%5.2f NMI:%5.2f Purity:%5.2f Fscore:%5.2f Precision:%5.2f AR:%5.2f Entropy:%5.2f  Recall:%5.2f\n',TM,ACC,MIhat,purity, Fscore,Precision,AR,Entropy,Recall);
if retry~=1 %ֻ����һ��ʱ������Ҫ���㷽��
    fprintf(fileID,'ST:%5.2f SAC:%5.2f SNM:%5.2f SPurit:%5.2f SFscor:%5.2f SPrecisio:%5.2f SA:%5.2f SEntrop:%5.2f SRecal:%5.2f\n\n',sTM,sACC,sMIhat,spurity,sFscore,sPrecision,sAR,sEntropy,sRecall);
else
    fprintf(fileID,'\n');
end
fclose(fileID);